﻿using System.Collections.Generic;

namespace SharpSword.SDK
{
    internal interface IHttpWebUtils
    {
        int Timeout { get; set; }
        HttpRespBody DoGet(string url, IDictionary<string, string> parameters);
        HttpRespBody DoPost(string url, IDictionary<string, string> parameters);
        HttpRespBody DoPost(string url, IDictionary<string, string> textParams, IDictionary<string, FileItem> fileParams);
    }
}