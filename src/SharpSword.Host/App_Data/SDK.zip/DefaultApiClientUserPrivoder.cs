﻿/******************************************************************
 * SharpSword zhangliang@sharpsword.com.cn 2016/4/21 17:04:09
 * ****************************************************************/
using System;

namespace SharpSword.SDK
{
    /// <summary>
    /// 默认用户获取提供者，用于测试
    /// </summary>
    public class DefaultApiClientUserPrivoder : IApiClientUserPrivoder
    {
        /// <summary>
        /// 
        /// </summary>
        private static ApiUser _apiUser = new ApiUser("000000", "system");

        /// <summary>
        /// 我们直接获取下定义的测试用户信息
        /// </summary>
        /// <returns></returns>
        public ApiUser Get()
        {
            return _apiUser;
        }
    }
}
