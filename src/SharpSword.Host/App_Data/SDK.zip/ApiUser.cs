﻿/******************************************************************
 * SharpSword zhangliang@sharpsword.com.cn 2016/3/22 16:30:45
 * ****************************************************************/
using System;

namespace SharpSword.SDK
{
    /// <summary>
    /// 当前操作用户
    /// </summary>
    public class ApiUser
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userName"></param>
        public ApiUser(string userId, string userName)
        {
            this.UserId = userId;
            this.UserName = userName;
        }

        /// <summary>
        /// 当前请求接口用户ID
        /// </summary>
        public string UserId { get; private set; }

        /// <summary>
        /// 当前请求接口用户名称
        /// </summary>
        public string UserName { get; private set; }
    }
}
