﻿/******************************************************************
 * SharpSword zhangliang@sharpsword.com.cn 2016/4/21 17:04:09
 * ****************************************************************/
using System;

namespace SharpSword.SDK
{
    /// <summary>
    /// SDK调用者获取提供者
    /// </summary>
    public interface IApiClientUserPrivoder
    {
        /// <summary>
        /// 获取当前调用API接口的用户信息
        /// </summary>
        /// <returns></returns>
        ApiUser Get();
    }
}
